// const person={   //person is a object
//     firstName:"santhiya",
//     lastName:"priya",
//     age:22,
//     parent:{
//         father:"appa",
//         mother:"amma"
//     },

//     fullName(){//fullName is a method 
//         return `${this.firstName} ${this.age}`
//     },
// }
// const person1={
//     message(){
//         console.log("2002")
//     },
//     favfood:"fish"
// }


// console.log(person.firstName)
// console.log(person.parent.father)
// console.log(person.fullName())
// Object.assign(person,person1)
// console.log(person)
// console.log(person.message())

